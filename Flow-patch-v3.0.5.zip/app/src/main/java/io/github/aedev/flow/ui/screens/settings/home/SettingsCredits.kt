package io.github.aedev.flow.ui.screens.settings.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import io.github.aedev.flow.R
import io.github.aedev.flow.ui.components.settings.SettingsListScope

private const val FLOW_URL = "https://github.com/Flow-Tube/Flow"
private const val CREATOR_URL = "https://github.com/A-EDev"
private const val FORK_OWNER_URL = "https://github.com/mohammedsamy18y5454-droid"

/** The credit at the very bottom of Settings: who forked this build, and thanks to the people who made Flow. */
internal fun SettingsListScope.credits() =
    item("home.credits") {
        val uriHandler = LocalUriHandler.current
        Column(
            modifier = Modifier.fillMaxWidth().padding(vertical = 24.dp, horizontal = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(
                text = stringResource(R.string.credits_forked_by),
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface,
            )
            Text(
                text = stringResource(R.string.credits_thanks),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
            )
            FilledTonalButton(
                onClick = { uriHandler.openUri(FLOW_URL) },
                modifier = Modifier.fillMaxWidth(),
            ) { Text(stringResource(R.string.credits_check_flow)) }
            OutlinedButton(
                onClick = { uriHandler.openUri(CREATOR_URL) },
                modifier = Modifier.fillMaxWidth(),
            ) { Text(stringResource(R.string.credits_check_creator)) }
            OutlinedButton(
                onClick = { uriHandler.openUri(FORK_OWNER_URL) },
                modifier = Modifier.fillMaxWidth(),
            ) { Text(stringResource(R.string.credits_check_fork)) }
        }
    }
