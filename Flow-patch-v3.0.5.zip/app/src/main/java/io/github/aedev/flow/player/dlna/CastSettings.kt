package io.github.aedev.flow.player.dlna

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Casting switches, readable from [DlnaCastManager] (which has no DI) as well as from Compose.
 *
 * - [legacyCodecMode]: cast only H.264 video + AAC audio, capped at 720p, in a plain MP4 whenever
 *   possible. No AV1, no VP9, no HEVC, no segmented fMP4 HLS. For old TVs such as 2011 Samsungs.
 * - [castingDisabled]: no cast pickers, no device discovery, nothing is ever sent to a renderer.
 */
object CastSettings {
    private const val FILE = "cast_settings"
    private const val KEY_LEGACY = "legacy_codec_mode"
    private const val KEY_DISABLED = "casting_disabled"

    /** Tallest picture legacy mode casts; a 32" 1366x768 panel gains nothing above this. */
    const val LEGACY_MAX_HEIGHT = 720

    /** Tallest picture of the MP4 Flow builds on the phone; lower keeps the wait before playing short. */
    const val LEGACY_MUX_MAX_HEIGHT = 480

    private var prefs: SharedPreferences? = null
    private val _legacyCodecMode = MutableStateFlow(false)
    private val _castingDisabled = MutableStateFlow(false)

    val legacyCodecMode: StateFlow<Boolean> = _legacyCodecMode.asStateFlow()
    val castingDisabled: StateFlow<Boolean> = _castingDisabled.asStateFlow()

    /** Loads the saved values once; safe to call from anywhere with any context. */
    @Synchronized
    fun init(context: Context) {
        if (prefs != null) return
        val p = context.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        prefs = p
        _legacyCodecMode.value = p.getBoolean(KEY_LEGACY, false)
        _castingDisabled.value = p.getBoolean(KEY_DISABLED, false)
    }

    fun setLegacyCodecMode(
        context: Context,
        enabled: Boolean,
    ) {
        init(context)
        prefs?.edit()?.putBoolean(KEY_LEGACY, enabled)?.apply()
        _legacyCodecMode.value = enabled
    }

    fun setCastingDisabled(
        context: Context,
        disabled: Boolean,
    ) {
        init(context)
        prefs?.edit()?.putBoolean(KEY_DISABLED, disabled)?.apply()
        _castingDisabled.value = disabled
        if (disabled) {
            DlnaCastManager.stopDiscovery()
            DlnaCastManager.disconnect()
        }
    }
}
