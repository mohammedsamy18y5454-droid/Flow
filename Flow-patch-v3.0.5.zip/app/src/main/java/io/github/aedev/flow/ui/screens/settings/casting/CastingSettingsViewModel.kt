package io.github.aedev.flow.ui.screens.settings.casting

import android.content.Context
import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import io.github.aedev.flow.player.dlna.CastSettings
import kotlinx.coroutines.flow.StateFlow
import javax.inject.Inject

@HiltViewModel
class CastingSettingsViewModel
    @Inject
    constructor(
        @ApplicationContext private val context: Context,
    ) : ViewModel() {
        init {
            CastSettings.init(context)
        }

        val legacyCodecMode: StateFlow<Boolean> = CastSettings.legacyCodecMode
        val castingDisabled: StateFlow<Boolean> = CastSettings.castingDisabled

        fun setLegacyCodecMode(enabled: Boolean) = CastSettings.setLegacyCodecMode(context, enabled)

        fun setCastingDisabled(disabled: Boolean) = CastSettings.setCastingDisabled(context, disabled)
    }
