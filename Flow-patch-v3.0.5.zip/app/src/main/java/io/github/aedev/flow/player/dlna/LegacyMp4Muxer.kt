package io.github.aedev.flow.player.dlna

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.OutputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import kotlin.coroutines.coroutineContext

/**
 * Builds one plain progressive MP4 (H.264 video + AAC audio, nothing re-encoded) from YouTube's
 * separate video and audio streams, for TVs that cannot play HLS or fragmented streams.
 * The finished file has its index (moov) at the front, so an old renderer can start at once.
 */
internal object LegacyMp4Muxer {
    private const val DIR = "legacy_cast"
    private const val BUFFER_SIZE = 4 * 1024 * 1024

    suspend fun build(
        context: Context,
        videoUrl: String,
        audioUrl: String,
        onProgress: (Float) -> Unit = {},
    ): File =
        withContext(Dispatchers.IO) {
            val dir = File(context.cacheDir, DIR).apply { mkdirs() }
            dir.listFiles()?.forEach { it.delete() }
            val raw = File(dir, "raw.mp4")
            val out = File(dir, "cast.mp4")
            try {
                mux(videoUrl, audioUrl, raw, onProgress)
                faststart(raw, out)
                onProgress(1f)
            } catch (e: Throwable) {
                out.delete()
                throw e
            } finally {
                raw.delete()
            }
            out
        }

    private suspend fun mux(
        videoUrl: String,
        audioUrl: String,
        target: File,
        onProgress: (Float) -> Unit,
    ) {
        val video = MediaExtractor()
        val audio = MediaExtractor()
        var muxer: MediaMuxer? = null
        var started = false
        try {
            video.setDataSource(videoUrl)
            audio.setDataSource(audioUrl)
            val videoTrack = findTrack(video, "video/")
            val audioTrack = findTrack(audio, "audio/")
            video.selectTrack(videoTrack)
            audio.selectTrack(audioTrack)

            muxer = MediaMuxer(target.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val videoFormat = video.getTrackFormat(videoTrack)
            val durationUs =
                if (videoFormat.containsKey(MediaFormat.KEY_DURATION)) videoFormat.getLong(MediaFormat.KEY_DURATION) else 0L
            val videoOut = muxer.addTrack(videoFormat)
            val audioOut = muxer.addTrack(audio.getTrackFormat(audioTrack))
            muxer.start()
            started = true

            val buffer = ByteBuffer.allocateDirect(BUFFER_SIZE)
            val info = MediaCodec.BufferInfo()
            var count = 0
            while (true) {
                val videoTime = video.sampleTime
                val audioTime = audio.sampleTime
                if (videoTime < 0 && audioTime < 0) break
                val useVideo =
                    if (videoTime < 0) {
                        false
                    } else if (audioTime < 0) {
                        true
                    } else {
                        videoTime <= audioTime
                    }
                val extractor = if (useVideo) video else audio
                val track = if (useVideo) videoOut else audioOut
                buffer.clear()
                val size = extractor.readSampleData(buffer, 0)
                if (size < 0) {
                    extractor.advance()
                    continue
                }
                val flags = if ((extractor.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
                info.set(0, size, extractor.sampleTime, flags)
                muxer.writeSampleData(track, buffer, info)
                extractor.advance()
                count++
                if (count % 128 == 0) {
                    coroutineContext.ensureActive()
                    if (durationUs > 0) onProgress((info.presentationTimeUs.toFloat() / durationUs).coerceIn(0f, 0.99f))
                }
            }
        } finally {
            runCatching { if (started) muxer?.stop() }
            runCatching { muxer?.release() }
            runCatching { video.release() }
            runCatching { audio.release() }
        }
    }

    private fun findTrack(
        extractor: MediaExtractor,
        prefix: String,
    ): Int {
        for (i in 0 until extractor.trackCount) {
            val mime = extractor.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: continue
            if (mime.startsWith(prefix)) return i
        }
        throw IllegalStateException("No $prefix track in stream")
    }

    // ── Move the moov box to the front ─────────────────────────────────────────

    private class Box(
        val type: String,
        val start: Long,
        val size: Long,
    )

    private fun faststart(
        src: File,
        dst: File,
    ) {
        RandomAccessFile(src, "r").use { input ->
            val boxes = readBoxes(input)
            val moovIndex = boxes.indexOfFirst { it.type == "moov" }
            val mdatIndex = boxes.indexOfFirst { it.type == "mdat" }
            if (moovIndex < 0 || mdatIndex < 0) throw IllegalStateException("Muxed file has no moov or mdat")
            if (moovIndex < mdatIndex) {
                src.copyTo(dst, overwrite = true)
                return
            }
            val moov = boxes[moovIndex]
            val moovBytes = ByteArray(moov.size.toInt())
            input.seek(moov.start)
            input.readFully(moovBytes)
            patchOffsets(moovBytes, 8, moovBytes.size, moov.size)

            val copyBuffer = ByteArray(256 * 1024)
            dst.outputStream().buffered().use { out ->
                boxes.forEachIndexed { index, box ->
                    if (index == mdatIndex) out.write(moovBytes)
                    if (index != moovIndex) copyRange(input, out, box.start, box.size, copyBuffer)
                }
            }
        }
    }

    private fun readBoxes(file: RandomAccessFile): List<Box> {
        val boxes = mutableListOf<Box>()
        val length = file.length()
        val header = ByteArray(16)
        var pos = 0L
        while (pos + 8 <= length) {
            file.seek(pos)
            file.readFully(header, 0, 8)
            var size = u32(header, 0)
            val type = String(header, 4, 4, Charsets.ISO_8859_1)
            if (size == 1L) {
                file.readFully(header, 8, 8)
                size = u64(header, 8)
            } else if (size == 0L) {
                size = length - pos
            }
            if (size < 8 || pos + size > length) break
            boxes += Box(type, pos, size)
            pos += size
        }
        return boxes
    }

    private fun copyRange(
        input: RandomAccessFile,
        out: OutputStream,
        start: Long,
        size: Long,
        buffer: ByteArray,
    ) {
        input.seek(start)
        var left = size
        while (left > 0) {
            val read = input.read(buffer, 0, minOf(buffer.size.toLong(), left).toInt())
            if (read < 0) break
            out.write(buffer, 0, read)
            left -= read
        }
    }

    /** Adds [delta] to every chunk offset (stco and co64) found inside [start, end) of the moov bytes. */
    private fun patchOffsets(
        b: ByteArray,
        start: Int,
        end: Int,
        delta: Long,
    ) {
        var pos = start
        while (pos + 8 <= end) {
            val size = u32(b, pos).toInt()
            val type = String(b, pos + 4, 4, Charsets.ISO_8859_1)
            if (size < 8 || pos + size > end) return
            when (type) {
                "trak", "mdia", "minf", "stbl" -> patchOffsets(b, pos + 8, pos + size, delta)
                "stco" -> {
                    val count = u32(b, pos + 12).toInt()
                    for (i in 0 until count) {
                        val at = pos + 16 + i * 4
                        put32(b, at, u32(b, at) + delta)
                    }
                }
                "co64" -> {
                    val count = u32(b, pos + 12).toInt()
                    for (i in 0 until count) {
                        val at = pos + 16 + i * 8
                        put64(b, at, u64(b, at) + delta)
                    }
                }
            }
            pos += size
        }
    }

    private fun u32(
        b: ByteArray,
        o: Int,
    ): Long =
        ((b[o].toLong() and 0xFF) shl 24) or
            ((b[o + 1].toLong() and 0xFF) shl 16) or
            ((b[o + 2].toLong() and 0xFF) shl 8) or
            (b[o + 3].toLong() and 0xFF)

    private fun u64(
        b: ByteArray,
        o: Int,
    ): Long = (u32(b, o) shl 32) or u32(b, o + 4)

    private fun put32(
        b: ByteArray,
        o: Int,
        v: Long,
    ) {
        b[o] = (v shr 24).toByte()
        b[o + 1] = (v shr 16).toByte()
        b[o + 2] = (v shr 8).toByte()
        b[o + 3] = v.toByte()
    }

    private fun put64(
        b: ByteArray,
        o: Int,
        v: Long,
    ) {
        put32(b, o, v shr 32)
        put32(b, o + 4, v and 0xFFFFFFFFL)
    }
}
