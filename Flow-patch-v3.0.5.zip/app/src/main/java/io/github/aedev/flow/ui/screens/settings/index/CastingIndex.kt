package io.github.aedev.flow.ui.screens.settings.index

import io.github.aedev.flow.R
import io.github.aedev.flow.ui.components.settings.SettingEntry
import io.github.aedev.flow.ui.components.settings.SettingsDestination

internal object CastingIndex {
    private val page = SettingsDestination.CASTING

    private fun entry(
        key: String,
        title: Int,
        section: Int,
        summary: Int? = null,
    ) = SettingEntry(
        key = "casting.$key",
        title = title,
        summary = summary,
        section = section,
        keywords = R.string.settings_keywords_casting,
        destination = page,
    )

    val legacyCodec =
        entry("legacy_codec", R.string.cast_legacy_mode_title, R.string.settings_section_casting_compat, R.string.cast_legacy_mode_summary)
    val disable =
        entry("disable", R.string.cast_disable_title, R.string.settings_section_casting_access, R.string.cast_disable_summary)

    val all = listOf(legacyCodec, disable)
}
