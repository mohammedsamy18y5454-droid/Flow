package io.github.aedev.flow.ui.components.shared

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Cast
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import io.github.aedev.flow.R
import io.github.aedev.flow.player.dlna.DlnaCastManager

/**
 * A Material 3 card at the bottom of the app that shows how far the MP4 for an old TV is built:
 * percent, time left, a progress bar, and a Cancel button. It only exists while Legacy mode builds a file.
 */
@Composable
fun CastPrepareCard(modifier: Modifier = Modifier) {
    val prepare by DlnaCastManager.prepare.collectAsStateWithLifecycle()
    val last = remember { arrayOfNulls<DlnaCastManager.CastPrepare>(1) }
    prepare?.let { last[0] = it }
    val shown = prepare ?: last[0]

    AnimatedVisibility(
        visible = prepare != null,
        enter = slideInVertically { it } + fadeIn(),
        exit = slideOutVertically { it } + fadeOut(),
        modifier = modifier,
    ) {
        val state = shown ?: return@AnimatedVisibility
        val progress by animateFloatAsState(targetValue = state.fraction, label = "castPrepareProgress")
        val percent = (state.fraction * 100).toInt().coerceIn(0, 100)
        val eta =
            state.etaSeconds?.let {
                if (it < 60) {
                    stringResource(R.string.cast_eta_seconds, it)
                } else {
                    stringResource(R.string.cast_eta_minutes, (it + 59) / 60)
                }
            }
        Surface(
            modifier =
                Modifier
                    .navigationBarsPadding()
                    .padding(start = 16.dp, end = 16.dp, bottom = 88.dp)
                    .fillMaxWidth(),
            shape = MaterialTheme.shapes.extraLarge,
            color = MaterialTheme.colorScheme.secondaryContainer,
            contentColor = MaterialTheme.colorScheme.onSecondaryContainer,
            tonalElevation = 6.dp,
            shadowElevation = 6.dp,
        ) {
            Column(modifier = Modifier.padding(start = 16.dp, end = 8.dp, top = 12.dp, bottom = 12.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Icon(Icons.Rounded.Cast, contentDescription = null, modifier = Modifier.size(24.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = stringResource(R.string.cast_prepare_title),
                            style = MaterialTheme.typography.titleSmall,
                        )
                        Text(
                            text =
                                if (eta != null) {
                                    stringResource(R.string.cast_prepare_text, percent, eta)
                                } else {
                                    stringResource(R.string.cast_prepare_text_short, percent)
                                },
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                    TextButton(onClick = { DlnaCastManager.cancelPrepare() }) {
                        Text(stringResource(R.string.cast_prepare_cancel))
                    }
                }
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp, end = 8.dp),
                    color = MaterialTheme.colorScheme.primary,
                    trackColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.6f),
                )
            }
        }
    }
}
