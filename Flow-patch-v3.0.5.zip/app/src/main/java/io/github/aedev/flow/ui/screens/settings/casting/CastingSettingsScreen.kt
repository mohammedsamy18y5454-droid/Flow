package io.github.aedev.flow.ui.screens.settings.casting

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Block
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Tv
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.res.stringResource
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import io.github.aedev.flow.R
import io.github.aedev.flow.ui.components.settings.SettingsPage
import io.github.aedev.flow.ui.components.settings.notice
import io.github.aedev.flow.ui.components.settings.switch
import io.github.aedev.flow.ui.components.settings.toggleGroup
import io.github.aedev.flow.ui.components.shared.FlowToggleOption
import io.github.aedev.flow.player.dlna.CastSettings
import io.github.aedev.flow.ui.screens.settings.index.CastingIndex

/** Casting options: a compatibility mode for old TVs, and a switch that forbids casting entirely. */
@Composable
internal fun CastingSettingsScreen(
    onBack: (() -> Unit)?,
    highlight: String?,
    viewModel: CastingSettingsViewModel = hiltViewModel(),
) {
    val disabled by viewModel.castingDisabled.collectAsStateWithLifecycle()

    SettingsPage(
        title = stringResource(R.string.settings_casting_title),
        onBack = onBack,
        highlight = highlight,
    ) {
        notice("casting.about", text = { stringResource(R.string.cast_settings_description) }, icon = Icons.Outlined.Info)
        group(key = "casting.compat", header = R.string.settings_section_casting_compat) {
            switch(
                CastingIndex.legacyCodec,
                viewModel.legacyCodecMode,
                viewModel::setLegacyCodecMode,
                enabled = !disabled,
                icon = Icons.Outlined.Tv,
            )
            toggleGroup(
                CastingIndex.quality,
                CastSettings.MUX_HEIGHTS.map { FlowToggleOption(it, "${it}p") },
                viewModel.muxMaxHeight,
                viewModel::setMuxMaxHeight,
                enabled = !disabled,
            )
        }
        group(key = "casting.access", header = R.string.settings_section_casting_access) {
            switch(
                CastingIndex.disable,
                viewModel.castingDisabled,
                viewModel::setCastingDisabled,
                icon = Icons.Outlined.Block,
            )
        }
    }
}
