package io.github.aedev.flow.player.dlna

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import io.github.aedev.flow.R

/** Shows a progress notification (percent done and time left) while Legacy mode builds the MP4. */
internal class CastPrepareNotifier(
    private val context: Context,
) {
    private val startMs = System.currentTimeMillis()
    private var lastPercent = -1
    private val allowed =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    init {
        if (allowed && Build.VERSION.SDK_INT >= 26) {
            val channel =
                NotificationChannel(
                    CHANNEL_ID,
                    context.getString(R.string.cast_prepare_channel),
                    NotificationManager.IMPORTANCE_LOW,
                )
            context.getSystemService(NotificationManager::class.java)?.createNotificationChannel(channel)
        }
    }

    @SuppressLint("MissingPermission")
    fun update(fraction: Float) {
        val percent = (fraction * 100).toInt().coerceIn(0, 100)
        if (percent == lastPercent) return
        lastPercent = percent
        val elapsedSec = (System.currentTimeMillis() - startMs) / 1000.0
        val leftSeconds =
            if (fraction > 0.03f && percent < 100) {
                (elapsedSec * (1 - fraction) / fraction).toInt().coerceAtLeast(1)
            } else {
                null
            }
        DlnaCastManager.publishPrepare(DlnaCastManager.CastPrepare(fraction.coerceIn(0f, 1f), leftSeconds))
        if (!allowed) return
        val text =
            if (leftSeconds != null) {
                val left = leftSeconds
                val eta =
                    if (left < 60) {
                        context.getString(R.string.cast_eta_seconds, left)
                    } else {
                        context.getString(R.string.cast_eta_minutes, (left + 59) / 60)
                    }
                context.getString(R.string.cast_prepare_text, percent, eta)
            } else {
                context.getString(R.string.cast_prepare_text_short, percent)
            }
        val notification =
            NotificationCompat
                .Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notification_logo)
                .setContentTitle(context.getString(R.string.cast_prepare_title))
                .setContentText(text)
                .setProgress(100, percent, false)
                .setOnlyAlertOnce(true)
                .setOngoing(true)
                .setSilent(true)
                .build()
        runCatching { NotificationManagerCompat.from(context).notify(NOTIFICATION_ID, notification) }
    }

    fun finish() {
        DlnaCastManager.publishPrepare(null)
        runCatching { NotificationManagerCompat.from(context).cancel(NOTIFICATION_ID) }
    }

    private companion object {
        const val CHANNEL_ID = "cast_prepare"
        const val NOTIFICATION_ID = 7421
    }
}
